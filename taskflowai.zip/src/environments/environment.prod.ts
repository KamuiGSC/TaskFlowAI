export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyB6SST32kYMeIPhTzY8-pwT_QSDGj-7-DQ",
    authDomain: "taskflowai-3f6df.firebaseapp.com",
    projectId: "taskflowai-3f6df",
    storageBucket: "taskflowai-3f6df.firebasestorage.app",
    messagingSenderId: "356695377209",
    appId: "1:356695377209:web:6c61d87c55bdabb07694e8",
    measurementId: "G-7LM1J2XL10"
  }
};
